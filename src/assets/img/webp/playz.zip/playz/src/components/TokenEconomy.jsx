import React from "react";
import { Wallet, Trophy, Star } from "lucide-react";

const TokenEconomy = () => {
  const distributions = [
    { name: "Community Rewards", percentage: 40 },
    { name: "Development", percentage: 20 },
    { name: "Liquidity", percentage: 15 },
    { name: "Team & Advisors", percentage: 15 },
    { name: "Marketing", percentage: 10 },
  ];

  return (
    <div className=" py-20 md:py-40">
      <div className="container px-4 mx-auto">
        <h1 className="text-4xl font-bold text-white mb-4">
          Sustainable <span className="text-purple-400">Token Economy</span>
        </h1>
        <p className="text-gray-300 mb-8">
          Our tokenomics model rewards active participation while maintaining
          long-term value through strategic burning and staking mechanisms.
        </p>

        <div className="space-y-4 mb-12">
          <div className="flex items-center gap-3 text-gray-200">
            <Wallet className="w-5 h-5 text-purple-400" />
            <span>Earn tokens through active participation</span>
          </div>
          <div className="flex items-center gap-3 text-gray-200">
            <Trophy className="w-5 h-5 text-purple-400" />
            <span>Stake to unlock premium features</span>
          </div>
          <div className="flex items-center gap-3 text-gray-200">
            <Star className="w-5 h-5 text-purple-400" />
            <span>Trade achievement NFTs in marketplace</span>
          </div>
        </div>

        <div
          className=" backdrop-blur-sm 
    p-8 
    bg-purple-900/30 
    border-purple-500/20 
    border 
    rounded-2xl"
        >
          <h2 className="text-2xl font-bold text-white mb-6">
            Token Distribution
          </h2>

          <div className="space-y-4">
            {distributions.map((item) => (
              <div
                key={item.name}
                className="flex justify-between items-center"
              >
                <span className="text-gray-300">{item.name}</span>
                <span className="text-white font-medium">
                  {item.percentage}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TokenEconomy;
