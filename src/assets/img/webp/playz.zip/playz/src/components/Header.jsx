import React from "react";
import { SparklesIcon } from "lucide-react";

const Header = () => {
  return (
    <>
      <main className=" container px-4 mx-auto  pt-16">
        <div
          className=" 
    text-purple-300 
    py-2 
    px-4 
    bg-purple-600/20 
    border-purple-500/20 
    border 
    rounded-full 
    items-center 
    inline-flex mb-8"
        >
          <SparklesIcon className="w-4 h-4" />
          <span className="text-sm ps-2 max-sm:text-xs">
            Play-to-Earn Sports Gaming Platform
          </span>
        </div>
        <h1 className="text-5xl font-bold mb-4">
          Level Up Your
          <div className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-400 block mt-2">
            Sports Journey with Web3
          </div>
        </h1>
        <p className="text-gray-300 text-xl mb-8 max-w-full">
          Transform your athletic achievements into digital assets. Compete,
          collect, and earn in the first tokenized sports gaming ecosystem.
        </p>
        <div className="flex gap-4 mb-16">
          <button
            className="transition-all  max-sm:text-xs
    duration-150 
    ease-in-out 
    py-3 
    px-8 
    bg-gradient-to-r 
    from-purple-500 
    via-pink-500 
    to-indigo-500 
    rounded-full font-medium hover:opacity-90"
          >
            Start Earning
          </button>
          <button
            className="transition-all max-sm:text-xs
    duration-150 
    ease-in-out 
    backdrop-blur-sm 
    py-3 
    px-8 
    bg-purple-900/50 
    border-purple-500/30 
    border 
    rounded-full font font-medium hover:bg-purple-800/50"
          >
            View Tokenomics
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div
            className=" backdrop-blur-sm 
    p-4 
    bg-purple-900/30 
    border-purple-500/20 
    border 
    rounded-xl"
          >
            <div className="text-3xl font-bold mb-2">$2.5M</div>
            <div className="text-gray-400">Total Value Locked</div>
          </div>
          <div
            className=" backdrop-blur-sm 
    p-4 
    bg-purple-900/30 
    border-purple-500/20 
    border 
    rounded-xl"
          >
            <div className="text-3xl font-bold mb-2">12K+</div>
            <div className="text-gray-400">Active Players</div>
          </div>
          <div
            className=" backdrop-blur-sm 
    p-4 
    bg-purple-900/30 
    border-purple-500/20 
    border 
    rounded-xl"
          >
            <div className="text-3xl font-bold mb-2">150K</div>
            <div className="text-gray-400">PLYZ Distributed</div>
          </div>
        </div>
      </main>
      <div className=" container px-4 mx-auto pt-20">
        <img
          src="https://images.webofknowledge.com/akamai/files/600x400.gif"
          alt="Placeholder"
          className="w-full  rounded-lg"
        />
      </div>
    </>
  );
};

export default Header;
