import React from "react";
import Logo from "../assets/plyaz logo.svg";
import { Link } from "react-router-dom";

const Nav = () => {
  return (
    <nav className="flex container px-4 mx-auto justify-between items-center">
      <div className="text-2xl font-bold">
        <Link to="/">
          <img
            src={Logo}
            className=" w-[60px] h-[60px] sm:w-[100px] sm:h-[100px]"
          />
        </Link>
      </div>
      <div className="flex gap-4 items-center">
        <Link
          to="/Players"
          className="text-gray-300 hover:text-white max-sm:text-[10px]"
        >
          For Players
        </Link>
        <Link
          to="/Investors"
          className="text-gray-300 hover:text-white max-sm:text-[10px]"
        >
          For Investors
        </Link>
        <button className=" max-sm:text-[10px] duration-150 ease-in-out backdrop-blur-sm py-2 px-6 bg-purple-600/30 border-purple-500/50 border rounded-full hover:bg-purple-600/50 transition">
          Connect Wallet
        </button>
      </div>
    </nav>
  );
};

export default Nav;
