import React from "react";
import { Smartphone, Link, Shield } from "lucide-react";

const FeatureSection = () => {
  return (
    <div className=" container px-4 mx-auto pt-20 md:pt-40">
      <h1 className="text-center text-4xl font-bold text-white mb-16">
        The Future of <span className="text-purple-400">Sports Gaming</span> is
        Here
      </h1>
      <div className=" container mx-auto space-y-6">
        <FeatureCard
          icon={<Smartphone className="w-6 h-6" />}
          title="Gamified Experience"
          description="Turn real sports achievements into digital rewards. Level up, earn XP, and unlock exclusive content."
        />
        <FeatureCard
          icon={<Link className="w-6 h-6" />}
          title="Play-to-Earn Mechanics"
          description="Earn $PLYZ tokens for participating, winning tournaments, and contributing to the community."
        />
        <FeatureCard
          icon={<Shield className="w-6 h-6" />}
          title="NFT Achievements"
          description="Collect and trade unique NFTs representing your sports milestones and achievements."
        />
      </div>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }) => {
  return (
    <div
      className=" p-6 
    backdrop-blur-sm 
    bg-purple-900/30 
    border-purple-500/20 
    border 
    rounded-xl w-full"
    >
      <div className="text-purple-400 mb-4">{icon}</div>
      <h2 className="text-white text-xl font-semibold mb-2">{title}</h2>
      <p className="text-gray-300">{description}</p>
    </div>
  );
};

export default FeatureSection;
