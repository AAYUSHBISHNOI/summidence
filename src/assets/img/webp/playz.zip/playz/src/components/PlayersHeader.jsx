import React from "react";
import trophy from "../assets/svg/trophy.svg";

const PlayersHeader = () => {
  return (
    <>
      <header className="container px-4 mx-auto  py-16">
        <div className="  text-purple-300  py-2  px-4  bg-purple-600/20  border-purple-500/20 border rounded-full items-center inline-flex mb-8">
          {/* <SparklesIcon className="w-4 h-4" /> */}
          <img src={trophy} alt="trophy" />
          <span className="text-sm ps-2 max-sm:text-xs">
            Coming Soon - Join the Waitlist
          </span>
        </div>
        <h1 className="text-5xl font-bold mb-4">
          Play Sports.
          <div className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-400 block mt-2">
            Earn Rewards.
          </div>
        </h1>
        <p className="text-gray-300 text-xl mb-8 max-w-full">
          Join local games, track your achievements, and earn rewards for every
          game you play. Be the first to experience the future of amateur
          sports.
        </p>
        <div
          className=" transition-all sm:w-[520px] flex justify-between items-center
    duration-150 p-2
    bg-purple-900/50 
    border-purple-500/30 
    border 
    rounded-full  hover:bg-purple-800/50"
        >
          <input
            type="text"
            placeholder="Enter your email for early access"
            className="bg-transparent px-4 w-[320px] h-full py-0 border-none outline-none  max-sm:text-xs font text-white"
          />
          <button className="transition-all text-nowrap max-sm:text-xs duration-150 ease-in-out py-3  px-8  bg-gradient-to-r  from-purple-500  via-pink-500  to-indigo-500 rounded-full font-medium hover:opacity-90">
            Join Waitlist
          </button>
        </div>
        <div className="pt-8">
          <p className="opacity-[80%]">✓ Early access to the platform</p>
          <p className="opacity-[80%] pt-4">
            ✓ Exclusive founding member benefits
          </p>
          <p className="opacity-[80%] pt-4">✓ Priority access to tournaments</p>
        </div>
        <div className=" container px-4 mx-auto pt-14">
          <img
            src="https://images.webofknowledge.com/akamai/files/600x400.gif"
            alt="Placeholder"
            className="w-[700px]  rounded-3xl"
          />
        </div>
      </header>
    </>
  );
};

export default PlayersHeader;
