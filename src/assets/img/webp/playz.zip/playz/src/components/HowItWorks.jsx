import React from "react";

const HowItWorks = () => {
  return (
    <>
      <div className=" container px-4 mx-auto py-20 md:py-40">
        <h1 className="text-center text-4xl font-bold text-white mb-16">
          How It Works
        </h1>
        <div className=" container mx-auto space-y-6">
          <FeatureCard
            title="Find Games"
            description="Browse and join local games that match your skill level"
          />
          <FeatureCard
            title="Play & Track"
            description="Participate in games and track your achievements"
          />
          <FeatureCard
            title="Earn Rewards"
            description="Get PLYZ tokens for playing and achieving milestones"
          />
        </div>
      </div>
    </>
  );
};
const FeatureCard = ({ icon, title, description }) => {
  return (
    <div
      className=" p-6 
    backdrop-blur-sm 
    bg-purple-900/30 
    border-purple-500/20 
    border 
    rounded-xl w-full"
    >
      <h2 className="text-white text-xl font-semibold mb-2">{title}</h2>
      <p className="text-gray-300">{description}</p>
    </div>
  );
};

export default HowItWorks;
