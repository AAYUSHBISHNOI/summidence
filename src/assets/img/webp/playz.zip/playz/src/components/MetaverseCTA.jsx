import React from "react";

const MetaverseCTA = () => {
  return (
    <div className="  py-16">
      <div className=" container px-4 mx-auto">
        <div
          className=" text-center 
    sm:p-12 px-2 py-5 
    bg-gradient-to-r 
    from-purple-600 
    via-pink-600 
    to-indigo-600 
    border-purple-500/20 
    border 
    rounded-2xl 
    backdrop-blur-sm"
        >
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Join the Sports Metaverse?
          </h2>

          <p className="text-white/90 mb-8">
            Start earning rewards for your athletic achievements in the Web3
            era.
          </p>

          <div className="flex justify-center gap-4">
            <button className="bg-white text-purple-600 px-6 py-3 rounded-full font-medium hover:bg-gray-100 transition-colors max-sm:text-xs">
              Connect Wallet
            </button>
            <a href="/whitepaper.pdf" target="_blank" rel="noopener noreferrer">
                <div
                  className="text-white 
                    font-semibold max-sm:text-xs
                    py-3 
                    px-8 
                    bg-purple-900/50 
                    border-white/20 
                    border 
                    rounded-full transition hover:bg-purple-800/50"
                >
                  Read Whitepaper
                </div>
            </a>
 
          </div>
        </div>
      </div>
    </div>
  );
};

export default MetaverseCTA;
