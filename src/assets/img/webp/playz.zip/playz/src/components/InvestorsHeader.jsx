import React from "react";
import trending from "../assets/svg/trending.svg";
import arrow from "../assets/svg/arrow.svg";

const InvestorsHeader = () => {
  return (
    <>
      <header className="container px-4 mx-auto  py-16">
        <div className="  text-purple-300  py-2  px-4  bg-purple-600/20  border-purple-500/20 border rounded-full items-center inline-flex mb-8">
          <img src={trending} alt="trophy" />
          <span className="text-sm ps-2 max-sm:text-xs">Seed Round Open</span>
        </div>
        <h1 className="text-5xl font-bold mb-4">
          Revolutionizing the
          <div className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-400 block mt-2">
            $223B Amateur Sports Market
          </div>
        </h1>
        <p className="text-gray-300 text-xl mb-8 max-w-full">
          Join local games, track your achievements, and earn rewards for every
          game you play. Be the first to experience the future of amateur
          sports.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div
            className=" backdrop-blur-sm 
    p-4 
    bg-purple-900/30 
    border-purple-500/20 
    border 
    rounded-xl"
          >
            <div className="text-3xl font-bold mb-2">$223B</div>
            <div className="text-gray-400">TAM</div>
          </div>
          <div
            className=" backdrop-blur-sm 
    p-4 
    bg-purple-900/30 
    border-purple-500/20 
    border 
    rounded-xl"
          >
            <div className="text-3xl font-bold mb-2">30M+</div>
            <div className="text-gray-400">Target Users</div>
          </div>
          <div
            className=" backdrop-blur-sm 
    p-4 
    bg-purple-900/30 
    border-purple-500/20 
    border 
    rounded-xl"
          >
            <div className="text-3xl font-bold mb-2">$840</div>
            <div className="text-gray-400">ARPU</div>
          </div>
        </div>
        <div className=" backdrop-blur-sm mt-8 p-4 px-8 bg-purple-900/30  border-purple-500/20  border  rounded-xl">
          <div className="text-3xl font-bold mb-2">Connect With Us</div>
          <input
            type="text"
            placeholder="Name"
            className=" px-4 w-full mt-5 py-3 h-full rounded-lg border-none bg-purple-900/30 outline-none  max-sm:text-xs font text-white"
          />
          <input
            type="text"
            placeholder="Email"
            className=" px-4 w-full mt-5 py-3 h-full rounded-lg border-none bg-purple-900/30 outline-none  max-sm:text-xs font text-white"
          />
          <input
            type="text"
            placeholder="Organization"
            className=" px-4 w-full mt-5 py-3 h-full rounded-lg border-none bg-purple-900/30 outline-none  max-sm:text-xs font text-white"
          />
          <button className="w-full p-4 my-6 bg-gradient-to-r from-purple-400 via-pink-400 to-pink-500 text-white font-bold rounded-lg">
            Get Investment Package
          </button>
        </div>
        <div className=" backdrop-blur-sm mt-8 p-4 px-8 bg-purple-900/30  border-purple-500/20  border  rounded-xl">
          <div className="text-3xl font-bold mb-2 pt-5">
            Investment Highlights
          </div>
          <div className="flex items-center gap-1 pt-4">
            <img src={arrow} alt="arrow" />
            <p>First-mover advantage in Web3 sports</p>
          </div>
          <div className="flex items-center gap-1 pt-3">
            <img src={arrow} alt="arrow" />
            <p>Fatent-pending technology</p>
          </div>
          <div className="flex items-center gap-1 pt-3">
            <img src={arrow} alt="arrow" />
            <p>Strong founding team</p>
          </div>
          <div className="flex items-center gap-1 pt-3">
            <img src={arrow} alt="arrow" />
            <p>Clear path to monetization</p>
          </div>
          <div className="flex items-center gap-1 pt-3 pb-4">
            <img src={arrow} alt="arrow" />
            <p>Network effects driven growth</p>
          </div>
        </div>
        <div className=" backdrop-blur-sm mt-8 p-4 px-8 bg-purple-900/30  border-purple-500/20  border  rounded-xl">
          <div className="text-3xl font-bold mb-2 pt-5">Traction</div>

          <div className="flex items-center justify-between pt-2">
            <p className="pt-2">Waitlist Signups</p>
            <h4 className="font-medium">2,500+</h4>
          </div>
          <div className="flex items-center justify-between pt-3">
            <p className="pt-2">Development Progress</p>
            <h4 className="font-medium">60%</h4>
          </div>
          <div className="flex items-center justify-between pt-3 pb-4">
            <p className="pt-2">Partner Commitments</p>
            <h4 className="font-medium">12</h4>
          </div>
        </div>
      </header>
    </>
  );
};

export default InvestorsHeader;
