import "./App.css";
import { Routes, Route } from "react-router-dom";
import Nav from "./components/Nav";
import Home from "./pages/Home";
import Players from "./pages/Players";
import Investors from "./pages/Investors";

function App() {
  return (
    <div className="bg-gradient-to-br from-purple-900 to-blue-900 text-white">
      <Nav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Players" element={<Players />} />
        <Route path="/Investors" element={<Investors />} />
      </Routes>
    </div>
  );
}

export default App;
