import React from "react";
import PlayersHeader from "../components/PlayersHeader";
import HowItWorks from "../components/HowItWorks";

const Players = () => {
  return (
    <>
          <PlayersHeader />
          <HowItWorks/>
    </>
  );
};

export default Players;
