import React from "react";
import TokenEconomy from "../components/TokenEconomy";
import MetaverseCTA from "../components/MetaverseCTA";
import FeatureSection from "../components/FeatureSection";
import Header from "../components/Header";

const Home = () => {
  return (
    <>
      <Header />
      <FeatureSection />
      <TokenEconomy />
      <MetaverseCTA />
    </>
  );
};

export default Home;
