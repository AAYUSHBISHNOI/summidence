import React from "react";
import InvestorsHeader from "../components/InvestorsHeader";

const Investors = () => {
  return (
    <>
     <InvestorsHeader/>
    </>
  );
};

export default Investors;
